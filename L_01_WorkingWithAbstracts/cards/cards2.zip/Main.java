package cards;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        CardRank [] cardRank = CardRank.values();
        System.out.println("Card Ranks:");
        for (CardRank cardRanks : cardRank) {
            System.out.printf("Ordinal value: %d; Name value: %s%n", cardRanks.getOriginalValue(), cardRanks.getNamesValue());
        }
    }
}
