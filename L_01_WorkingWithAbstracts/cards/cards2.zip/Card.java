package cards;

public class Card {

    private CardRank cardRank;

    public Card(CardRank cardRank) {
        this.cardRank = cardRank;
    }
}
