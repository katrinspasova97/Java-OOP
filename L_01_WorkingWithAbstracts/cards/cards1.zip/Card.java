package cards;

public class Card {

    private CardSuit cardSuit;

    public Card(CardSuit cardSuit) {
        this.cardSuit = cardSuit;
    }

}
