package cards;

public enum CardSuit {
    CLUBS(0, "CLUBS"),
    DIAMONDS(1, "DIAMONDS"),
    HEARTS(2, "HEARTS"),
    SPADES(3, "SPADES");
    private int originalValue;
    private String namesValue;

    CardSuit(int originalValue, String namesValue) {
        this.originalValue = originalValue;
        this.namesValue = namesValue;
    }

    public int getOriginalValue() {
        return originalValue;
    }

    public void setOriginalValue(int originalValue) {
        this.originalValue = originalValue;
    }

    public String getNamesValue() {
        return namesValue;
    }

    public void setNamesValue(String namesValue) {
        this.namesValue = namesValue;
    }
}
