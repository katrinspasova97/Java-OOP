package trafficLight;

public enum Color {
    RED,
    GREEN,
    YELLOW;

}
