package L_03_P_01_SingleInheritance;

public class Animal {
    public void eat(){
        System.out.println("eating...");
    }
}
