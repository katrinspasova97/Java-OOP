package L_03_P_01_SingleInheritance;

public class Cat extends Animal{
    public void meow(){
        System.out.println("meowing…");
    }
}
