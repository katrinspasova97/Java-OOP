package L_03_P_04_StackOfStrings;

public class Main {
    public static void main(String[] args) {

    }
}
