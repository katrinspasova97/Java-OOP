package sayHello;

public interface Person {
    //+getName(): String
    //+sayHello(): String

    String getName();
    String sayHello();

}
